package com.mis.student_mis.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mis.student_mis.conn_class.db_settings;
import com.mis.student_mis.model.cls_course;
@RestController
@RequestMapping("/courses_service")
public class courses_service {
      cls_course course_1 = new cls_course();

    @Autowired
    private db_settings cls_db_config;

    @GetMapping("/list_of_courses")
    public String list_of_courses() {
        course_1.con = cls_db_config.getCon();
        String result = course_1.select_all_courses();

        return result;}
      @PostMapping("/register_courses")
    public String register_courses(@RequestBody String json_request) {
        course_1.con = cls_db_config.getCon();
        String result = course_1.register_new_courses(json_request);

        return result;}
    
    @GetMapping("/registered_courses")
    public String registered_courses() {
         course_1.con = cls_db_config.getCon();
         String result = course_1.select_registered_courses();
        return result;
}
}