package com.mis.student_mis.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mis.student_mis.conn_class.db_settings;
import com.mis.student_mis.model.cls_student;

@RestController
@RequestMapping("/students_service")
public class students_service {
     cls_student student_1 = new cls_student();

    @Autowired
    private db_settings cls_db_config;
    @CrossOrigin(origins="*")
    @GetMapping("/list_of_students")
    public String list_of_courses() {
        student_1.con = cls_db_config.getCon();
        String result = student_1.select_all_students();

        return result;}
    @CrossOrigin(origins="*")
    @PostMapping("/add_students")
    public String add_students(@RequestBody String json_request) {
        student_1.con = cls_db_config.getCon();
        String result = student_1.add_new_students(json_request);

        return result;}
    
        @CrossOrigin(origins="*")
        @GetMapping("/auth_student_login")
        public String auth_student_login(@RequestParam String student_id) {
          student_1.con = cls_db_config.getCon();
          String result = student_1.auth_student_login(student_id);
          return result;
        }   
    
}
