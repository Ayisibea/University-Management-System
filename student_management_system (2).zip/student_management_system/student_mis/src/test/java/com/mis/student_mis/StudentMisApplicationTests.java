package com.mis.student_mis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMisApplicationTests {

	@Test
	void contextLoads() {
	}

}
